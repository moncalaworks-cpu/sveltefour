Here is a random page that has no structure, no purpose, and no goals. Sometimes I just want to capture the weird, wackiness that is my brain.


## Hardware Stack

Macbook Pro M1
iPad
iPhone 13 Pro
Apple Watch
Air Pods

PT Gear
Toiletries
Belt
Backpack
Messenger

## Software Tech Stack

Svelte - Front End
SvelteKit - routing
Tailwind CSS - CSS
PostGreSQL - DB
Playwright - testing

Google - SSO
Obsidian - Project
Claude Code - AI
Vercel - hosting
Supabase - hosting


